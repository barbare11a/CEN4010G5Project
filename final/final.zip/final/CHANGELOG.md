## quickstart-spring-data-jdbc-mysql Changelog

<a name="1.0.0"></a>
# 1.0.0 (2020-07-02)

Initial release
